import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from scipy import stats

# Function to preprocess each dataset
def preprocess_dataset(dataset, dataset_name="Dataset"):
    input_columns = list(range(dataset.shape[1] - 1))  # Assume last column is output
    output_column = dataset.shape[1] - 1

    # Fill NaN values for input columns with 0
    for column in input_columns:
        if dataset.iloc[:, column].isnull().any():
            dataset.iloc[:, column] = dataset.iloc[:, column].fillna(0)

    # Check if the output column is entirely NaN
    if dataset.iloc[:, output_column].isnull().all():
        print(f"{dataset_name}: Output column {output_column} is all NaN. Dropping the column.")
        dataset.drop(dataset.columns[output_column], axis=1, inplace=True)
        # After dropping, adjust the input and output columns if necessary
        # For this example, we'll proceed without an output column if it's dropped
    else:
        # Fill NaN values for the output column if not all values are NaN
        dataset.iloc[:, output_column] = dataset.iloc[:, output_column].fillna(dataset.iloc[:, output_column].mean())
        # Normalize the output column
        output_scaler = MinMaxScaler()
        dataset.iloc[:, [output_column]] = output_scaler.fit_transform(dataset.iloc[:, [output_column]].values.reshape(-1, 1))

    # Normalize input columns
    scaler = MinMaxScaler()
    dataset.iloc[:, input_columns] = scaler.fit_transform(dataset.iloc[:, input_columns])

    return dataset

# Load the datasets
dataset1 = pd.read_csv('A1-turbine.csv', delimiter=',')
dataset2 = pd.read_csv('A1-synthetic.csv', delimiter=',')
dataset3 = pd.read_csv('A1-real_estate.csv', delimiter=',')

# Preprocess each dataset
dataset1 = preprocess_dataset(dataset1, "Dataset 1")
dataset2 = preprocess_dataset(dataset2, "Dataset 2")
dataset3 = preprocess_dataset(dataset3, "Dataset 3")

# Optionally, include outlier detection and other processing steps here

# Save the preprocessed datasets
dataset1.to_csv('normalized_dataset1.csv', index=False)
dataset2.to_csv('normalized_dataset2.csv', index=False)
dataset3.to_csv('normalized_dataset3.csv', index=False)

print("Preprocessing complete. Datasets saved.")
