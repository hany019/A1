import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from scipy import stats

# Function to normalize and process each dataset
def process_dataset(file_path, input_columns, output_column):
    dataset = pd.read_csv(file_path, delimiter=',')
    
    # Drop columns with NaN values entirely
    dataset.dropna(axis=1, how='any', inplace=True)
    
    # Ensure the input_columns list only contains columns that still exist in the dataset after dropping NaN columns
    input_columns = [column for column in input_columns if column in dataset.columns]
    
    # Initialize MinMaxScaler
    scaler = MinMaxScaler()
    
    # Normalize input columns if they exist in the dataset
    if input_columns:
        dataset[input_columns] = scaler.fit_transform(dataset[input_columns])
    
    # Normalize output column if it exists in the dataset
    if output_column in dataset.columns:
        dataset[[output_column]] = scaler.fit_transform(dataset[[output_column]])
    
    # Perform outlier detection using Z-score for input columns if they exist
    if input_columns:
        z_scores = np.abs(stats.zscore(dataset[input_columns]))
        z_score_threshold = 3
        outlier_indices = np.where(z_scores > z_score_threshold)
        outliers = dataset.iloc[outlier_indices[0]]
    
        # Display the outlier rows for the dataset
        if not outliers.empty:
            print(f"Outliers detected in dataset from file {file_path}:")
            print(outliers)
    
    return dataset

# Define columns for each dataset
turbine_columns = ['height_over_sea_level', 'fall', 'net', 'fall_1', 'flow']
synthetic_columns = ['v1', 'v2', 'v3', 'v4', 'v5', 'v6', 'v7', 'v8', 'v9']
real_state_columns = ['X1 transaction date', 'X2 house age', 'X3 distance to the nearest MRT station', 'X4 number of convenience stores', 'X5 latitude', 'X6 longitude']

# Process each dataset
dataset1 = process_dataset('A1-turbine.csv', turbine_columns, 'power_of_hydroelectrical_turbine')
dataset2 = process_dataset('A1-synthetic.csv', synthetic_columns, 'z')
dataset3 = process_dataset('A1-real_estate.csv', real_state_columns, 'Y house price of unit area')

# Save the processed datasets to separate CSV files
dataset1.to_csv('normalized_dataset1.csv', index=False)
dataset2.to_csv('normalized_dataset2.csv', index=False)
dataset3.to_csv('normalized_dataset3.csv', index=False)
