import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim


class MyNeuralNetwork(nn.Module):
    def __init__(self, num_layers, num_units, num_epochs, learning_rate, momentum, activation_function, validation_percentage):
        super(MyNeuralNetwork, self).__init__()
        self.L = num_layers
        self.n = num_units
        self.num_epochs = num_epochs
        self.eta = learning_rate
        self.alpha = momentum
        self.fact = activation_function
        self.validation_percentage = validation_percentage
        self.xi = [np.zeros(layer_units) for layer_units in num_units]
        self.h = [np.zeros(layer_units) for layer_units in num_units]
        self.w = [None] + [np.random.randn(num_units[i], num_units[i-1]) for i in range(1, num_layers)]
        self.theta = [np.zeros(layer_units) for layer_units in num_units]
        self.delta = [np.zeros(layer_units) for layer_units in num_units]
        self.layers = nn.ModuleList()
        for i in range(1, num_layers):
            self.layers.append(nn.Linear(num_units[i-1], num_units[i]))
            self.layers.append(nn.ReLU() if activation_function == "relu" else nn.Sigmoid())
    

    def forward(self, x):
        # Apply layers & activation function (except for the output layer)
        for i, layer in enumerate(self.layers):
            x = layer(x)
            if i < len(self.layers) - 1:  # No activation after the last layer
                if self.fact == 'relu':
                    x = F.relu(x)
                elif self.fact == 'sigmoid':
                    x = torch.sigmoid(x)
                elif self.fact == 'tanh':
                    x = torch.tanh(x)

        return x
    
    def sigmoid(self, x):
        return 1 / (1 + np.exp(-x))

    def sigmoid_derivative(self, x):
        return x * (1 - x)

    def relu(self, x):
        return np.maximum(0, x)

    def relu_derivative(self, x):
        return (x > 0).astype(float)

    def linear(self, x):
        return x

    def linear_derivative(self, x):
        return np.ones_like(x)

    def tanh(self, x):
        return np.tanh(x)

    def tanh_derivative(self, x):
        return 1 - x**2

    def activation(self, x):
        if self.fact == 'sigmoid':
            return self.sigmoid(x)
        elif self.fact == 'relu':
            return self.relu(x)
        elif self.fact == 'linear':
            return self.linear(x)
        elif self.fact == 'tanh':
            return self.tanh(x)

    def activation_derivative(self, x):
        if self.fact == 'sigmoid':
            return self.sigmoid_derivative(x)
        elif self.fact == 'relu':
            return self.relu_derivative(x)
        elif self.fact == 'linear':
            return self.linear_derivative(x)
        elif self.fact == 'tanh':
            return self.tanh_derivative(x)

    def feed_forward(self, sample):
        self.xi[0] = sample
        for l in range(1, self.L):
            self.h[l] = np.dot(self.w[l], self.xi[l - 1]) - self.theta[l]
            self.xi[l] = self.activation(self.h[l])

    def backpropagate(self, target):
        self.delta[self.L - 1] = self.activation_derivative(self.xi[self.L - 1]) * (self.xi[self.L - 1] - target)
        for l in range(self.L - 2, 0, -1):
            self.delta[l] = self.activation_derivative(self.xi[l]) * np.dot(self.w[l + 1].T, self.delta[l + 1])

    def update_weights(self):
        for l in range(1, self.L):
            # Gradient clipping
            grad = np.outer(self.delta[l], self.xi[l - 1])
            if np.linalg.norm(grad) > 1:
                grad = grad / np.linalg.norm(grad)

            self.w[l] -= self.eta * grad
            self.theta[l] -= self.eta * self.delta[l]
            
    def train_model(self, X, y, num_epochs, learning_rate, batch_size=32):
        self.training = True  # Explicitly set training mode
        optimizer = optim.Adam(self.parameters(), lr=learning_rate)
        criterion = nn.MSELoss()
        
        # Convert arrays to PyTorch tensors
        X_tensor = torch.tensor(X, dtype=torch.float32)
        y_tensor = torch.tensor(y, dtype=torch.float32).view(-1, 1)  # Reshape y to be a column vector if it's not already

        # Ensure the model is in training mode
        self.train()

        for epoch in range(num_epochs):
            permutation = torch.randperm(X_tensor.size()[0])
            epoch_losses = []

            for i in range(0, X_tensor.size()[0], batch_size):
                optimizer.zero_grad()

                indices = permutation[i:i+batch_size]
                batch_x, batch_y = X_tensor[indices], y_tensor[indices]

                # Forward pass
                outputs = self.forward(batch_x)
                
                # Compute loss
                loss = criterion(outputs, batch_y)
                
                # Backward pass and optimize
                loss.backward()
                optimizer.step()

                epoch_losses.append(loss.item())

            # Calculate average loss over the epoch
            avg_epoch_loss = sum(epoch_losses) / len(epoch_losses)
            print(f'Epoch {epoch+1}/{num_epochs}, Loss: {avg_epoch_loss}')

        return epoch_losses  # Return the list of average losses per epoch



    def predict(self, X):
        X_tensor = torch.tensor(X, dtype=torch.float32)
        predictions = self.forward(X_tensor)
        return predictions.detach().numpy()
    
    def calculate_loss(self, predictions, y_true):
        # PyTorch's mean squared error loss
        criterion = torch.nn.MSELoss()
        return criterion(predictions, y_true)
