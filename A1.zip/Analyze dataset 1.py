import numpy as np
import pandas as pd

# Load the datasets
try:
    dataset1 = pd.read_csv('A1-turbine.txt')
except FileNotFoundError:
    print("Error: 'A1-turbine.csv' file not found.")
    dataset1 = None
except pd.errors.EmptyDataError:
    print("Error: 'A1-turbine.csv' is empty.")
    dataset1 = None

try:
    dataset2 = pd.read_csv('A1-synthetic.txt')
except FileNotFoundError:
    print("Error: 'A1-synthetic.csv' file not found.")
    dataset2 = None
except pd.errors.EmptyDataError:
    print("Error: 'A1-synthetic.csv' is empty.")
    dataset2 = None

try:
    dataset3 = pd.read_csv('A1-real_estate.csv')
except FileNotFoundError:
    print("Error: 'A1-real_estate.csv' file not found.")
    dataset3 = None
except pd.errors.EmptyDataError:
    print("Error: 'A1-real_estate.csv' is empty.")
    dataset3 = None

# Function to remove columns with all NaN values
def remove_all_nan_columns(dataset, threshold=0.5):
    """
    Removes columns from the dataset where the proportion of NaN values 
    exceeds the specified threshold.

    :param dataset: Pandas DataFrame
    :param threshold: float, the threshold for the proportion of NaN values
    :return: Pandas DataFrame with columns removed
    """
    dataset = dataset.dropna(how='all', axis=1)  # Remove columns that are entirely NaN
    for column in dataset.columns:
        nan_ratio = dataset[column].isna().sum() / len(dataset)
        if nan_ratio > threshold:
            dataset = dataset.drop(column, axis=1)
    return dataset

# Analyze dataset 1 if it was successfully loaded
if dataset1 is not None:
    dataset1 = remove_all_nan_columns(dataset1, threshold=0.5)
    # Additional check if needed
    dataset1 = dataset1.dropna(axis=1, how='all')
    print("Dataset 1 Summary:")
    print(dataset1.describe())

# Analyze and preprocess dataset 2 if it was successfully loaded
if dataset2 is not None:
    dataset2 = remove_all_nan_columns(dataset2, threshold=0.5)
    dataset2 = dataset2.dropna(axis=1, how='all')
    print("Dataset 2 Summary:")
    print(dataset2.describe())

# Analyze and preprocess dataset 3 if it was successfully loaded
if dataset3 is not None:
    dataset3 = remove_all_nan_columns(dataset3, threshold=0.5)
    dataset3 = dataset3.dropna(axis=1, how='all')
    print("Dataset 3 Summary:")
    print(dataset3.describe())


def clean_data(dataset):
    numeric_cols = dataset.select_dtypes(include=[np.number])  # Select only numeric columns
    if not np.all(np.isfinite(numeric_cols)):
        dataset = dataset.replace([np.inf, -np.inf], np.nan)
        dataset = dataset.dropna()
    return dataset

