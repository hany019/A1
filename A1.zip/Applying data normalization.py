import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from scipy import stats

# Load the datasets
dataset1 = pd.read_csv('A1-turbine.csv', delimiter=',')  
dataset2 = pd.read_csv('A1-synthetic.csv', delimiter=',')
dataset3 = pd.read_csv('A1-real_estate.csv', delimiter=',')

# Rename the problematic column for Dataset 1 (remove spaces)
dataset1.rename(columns={'height over sea level': 'height_over_sea_level'}, inplace=True)

# Create a Min-Max scaler for input and output variables
scaler = MinMaxScaler() 

# Define input and output columns for each dataset

# Dataset 1 column names
input_columns1 = [0, 1, 2, 3, 4]  # Include all columns except the 4th column with NaN values
output_column1 = 5  # Use numeric index for the output column

# Fill NaN values in the 'power_of_hydroelectrical_turbine' column with the mean
dataset1['power_of_hydroelectrical_turbine'] = dataset1['power_of_hydroelectrical_turbine'].fillna(dataset1['power_of_hydroelectrical_turbine'].mean())

# Impute NaN values with the mean for each dataset in Dataset 1
for column in input_columns1:
    dataset1.iloc[:, column] = dataset1.iloc[:, column].fillna(dataset1.iloc[:, column].mean())

# Normalize input variables in Dataset 1
dataset1.iloc[:, input_columns1] = scaler.fit_transform(dataset1.iloc[:, input_columns1])

# Normalize output variable in Dataset 1
output_scaler1 = MinMaxScaler()
dataset1.iloc[:, output_column1] = output_scaler1.fit_transform(dataset1.iloc[:, [output_column1]])

# Perform outlier detection using Z-score for Dataset 1
z_score_threshold = 3  # Adjust the threshold as needed

# Z-score for Dataset 1
z_scores1 = np.abs(stats.zscore(dataset1.iloc[:, input_columns1]))
outlier_indices1 = np.where(z_scores1 > z_score_threshold)
outliers_dataset1 = dataset1.iloc[outlier_indices1[0]]

# Display the outlier rows for Dataset 1
print("Outliers in Dataset 1:")
print(outliers_dataset1)

# Dataset 2 column names
input_columns2 = [0, 1, 2, 3, 4, 5, 6, 7, 8]  # Use numeric indices for columns
output_column2 = 9  # Use numeric index for the output column

# Dataset 3 column names
input_columns3 = [0, 1, 2, 3, 4, 5]  # Use numeric indices for columns
output_column3 = 6  # Use numeric index for the output column

# Impute NaN values with the mean for each dataset in Dataset 2 and 3
for column in input_columns2:
    dataset2.iloc[:, column] = dataset2.iloc[:, column].fillna(dataset2.iloc[:, column].mean())

for column in input_columns3:
    dataset3.iloc[:, column] = dataset3.iloc[:, column].fillna(dataset3.iloc[:, column].mean())

# Normalize input variables in each dataset
dataset2.iloc[:, input_columns2] = scaler.fit_transform(dataset2.iloc[:, input_columns2])
dataset3.iloc[:, input_columns3] = scaler.fit_transform(dataset3.iloc[:, input_columns3])

# Normalize output variables in each dataset
output_scaler2 = MinMaxScaler()
dataset2.iloc[:, output_column2] = output_scaler2.fit_transform(dataset2.iloc[:, [output_column2]])

output_scaler3 = MinMaxScaler()
dataset3.iloc[:, output_column3] = output_scaler3.fit_transform(dataset3.iloc[:, [output_column3]])

# Perform outlier detection using Z-score for Dataset 2 and 3
# Z-score for Dataset 2
z_scores2 = np.abs(stats.zscore(dataset2.iloc[:, input_columns2]))
outlier_indices2 = np.where(z_scores2 > z_score_threshold)
outliers_dataset2 = dataset2.iloc[outlier_indices2[0]]

# Z-score for Dataset 3
z_scores3 = np.abs(stats.zscore(dataset3.iloc[:, input_columns3]))
outlier_indices3 = np.where(z_scores3 > z_score_threshold)
outliers_dataset3 = dataset3.iloc[outlier_indices3[0]]

# Display the outlier rows for Dataset 2 and 3
print("Outliers in Dataset 2:")
print(outliers_dataset2)

print("Outliers in Dataset 3:")
print(outliers_dataset3)

# Save the normalized datasets to separate CSV files
dataset1.to_csv('normalized_dataset1.csv', index=False)
dataset2.to_csv('normalized_dataset2.csv', index=False)
dataset3.to_csv('normalized_dataset3.csv', index=False)
